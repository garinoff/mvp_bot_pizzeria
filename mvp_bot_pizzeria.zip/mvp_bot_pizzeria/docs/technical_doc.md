# Documentazione Tecnica: Bot per Pizzerie Multilingua

## Panoramica del Progetto

Questo documento fornisce la documentazione tecnica completa per il bot per pizzerie multilingua sviluppato secondo le specifiche richieste. Il bot è progettato per funzionare su WhatsApp e Telegram, supportare tre lingue (italiano, russo e inglese), e gestire l'intero processo di ordinazione di pizze, dalla visualizzazione del menu fino alla conferma dell'ordine.

## Architettura del Sistema

L'architettura del bot è modulare e scalabile, progettata per facilitare l'aggiunta di nuove funzionalità e lingue in futuro. Il sistema è composto dai seguenti moduli principali:

### 1. Moduli Core

#### 1.1 Configurazione (`config.py`)
Gestisce tutte le impostazioni di configurazione del bot, inclusi token API, impostazioni di database, provider di pagamento e configurazioni multilingua.

#### 1.2 Gestore Traduzioni (`translations.py`)
Implementa un sistema completo di gestione delle traduzioni che supporta italiano, russo e inglese. Include:
- Repository centralizzato di stringhe tradotte
- Rilevamento automatico della lingua dell'utente
- Formattazione specifica per valuta in base alla lingua

#### 1.3 Database (`database.py`)
Fornisce un'interfaccia per la persistenza dei dati, utilizzando SQLite per l'MVP con una struttura progettata per facilitare la migrazione a PostgreSQL in futuro. Gestisce:
- Utenti e preferenze linguistiche
- Sessioni e stati di conversazione
- Ordini e dettagli di pagamento
- Menu e categorie di prodotti

#### 1.4 Gestore Ordini (`order_manager.py`)
Gestisce tutte le operazioni relative agli ordini:
- Creazione e gestione del carrello
- Aggiunta/rimozione di prodotti
- Calcolo dei totali
- Generazione di link di pagamento
- Creazione e aggiornamento degli ordini

#### 1.5 Gestore Conversazioni (`conversation_manager.py`)
Implementa la logica di conversazione e i flussi di dialogo:
- Gestione degli stati della conversazione
- Routing dei messaggi in base allo stato
- Generazione di risposte e pulsanti
- Gestione multilingua delle interazioni

### 2. Diagramma dell'Architettura

```
┌─────────────────────────────────────────────────────────────┐
│                      CANALI DI INGRESSO                     │
│                                                             │
│    ┌───────────────┐                 ┌───────────────┐      │
│    │   WhatsApp    │                 │   Telegram    │      │
│    │  Business API │                 │    Bot API    │      │
│    └───────┬───────┘                 └───────┬───────┘      │
└─────────────────────────────────────────────────────────────┘
              │                                 │
              └─────────────────┬───────────────┘
                                │
┌─────────────────────────────────────────────────────────────┐
│                    CORE DEL SISTEMA                         │
│                                                             │
│    ┌───────────────────────────────────────────────────┐    │
│    │              Gestore Conversazioni                │    │
│    │  (Gestisce il flusso di dialogo e le sessioni)    │    │
│    └─────────────────────────┬─────────────────────────┘    │
│                              │                              │
│    ┌─────────────────────────┼─────────────────────────┐    │
│    │                         │                         │    │
│    ▼                         ▼                         ▼    │
│ ┌─────────────┐      ┌──────────────┐          ┌────────────┐
│ │   Modulo    │      │    Modulo    │          │   Modulo   │
│ │  Linguistico│      │   Gestione   │          │  Gestione  │
│ │             │      │    Ordini    │          │   Pagamenti│
│ └─────┬───────┘      └──────┬───────┘          └─────┬──────┘
│       │                     │                        │       │
└───────┼─────────────────────┼────────────────────────┼───────┘
        │                     │                        │
┌───────┼─────────────────────┼────────────────────────┼───────┐
│       │     SERVIZI ESTERNI │                        │       │
│       │                     │                        │       │
│       ▼                     ▼                        ▼       │
│ ┌────────────┐      ┌──────────────┐          ┌─────────────┐
│ │ Repository │      │Google Sheets/│          │  Gateway    │
│ │ Traduzioni │      │  CMS Manus   │          │  Pagamenti  │
│ │            │      │ (Menu)       │          │(Stripe/Satis│
│ └────────────┘      └──────────────┘          │   pay)      │
│                                               └─────────────┘
└─────────────────────────────────────────────────────────────┘
```

## Flussi di Conversazione

Il bot implementa i seguenti flussi di conversazione, tutti disponibili nelle tre lingue supportate:

### 1. Flusso Principale
1. **Benvenuto**: Presentazione del bot e opzioni principali
2. **Menu**: Visualizzazione categorie e prodotti
3. **Carrello**: Gestione degli elementi selezionati
4. **Consegna/Ritiro**: Scelta del metodo di ricezione dell'ordine
5. **Pagamento**: Selezione del metodo di pagamento e completamento
6. **Conferma**: Riepilogo dell'ordine e conferma finale

### 2. Flussi Secondari
- **FAQ**: Risposte a domande frequenti
- **Cambio Lingua**: Possibilità di cambiare la lingua dell'interfaccia
- **Contatto**: Opzioni per contattare il ristorante

### 3. Stati della Conversazione
Il sistema utilizza una macchina a stati per gestire il flusso della conversazione:

```
WELCOME → MENU_CATEGORIES → MENU_ITEMS → CART → DELIVERY_METHOD → 
DELIVERY_ADDRESS → PAYMENT_METHOD → PAYMENT_PROCESSING → ORDER_CONFIRMATION
```

Con stati aggiuntivi per gestire le FAQ e altre funzionalità.

## Supporto Multilingua

### 1. Struttura delle Traduzioni
Le traduzioni sono organizzate in un dizionario gerarchico con chiavi nidificate:

```json
{
  "welcome": {
    "message": {
      "it": "Ciao 👋 Benvenuto nella nostra pizzeria!",
      "ru": "Привет 👋 Добро пожаловать в нашу пиццерию!",
      "en": "Hello 👋 Welcome to our pizzeria!"
    },
    "buttons": {
      "order": {
        "it": "Ordina una pizza 🍕",
        "ru": "Заказать пиццу 🍕",
        "en": "Order a pizza 🍕"
      }
    }
  }
}
```

### 2. Rilevamento Lingua
Il sistema implementa un algoritmo di rilevamento lingua che:
- Identifica caratteri cirillici per il russo
- Riconosce caratteri speciali e parole comuni per l'italiano
- Riconosce parole comuni per l'inglese
- Implementa un sistema di fallback intelligente

### 3. Adattamenti Culturali
- **Valuta**: Euro (€) per italiano e inglese, Rubli (₽) per russo
- **Formalità**: Variazioni nel livello di formalità in base alla lingua
- **Contenuto**: Adattamenti specifici per ciascuna cultura

## Gestione Dati

### 1. Schema Database
Il database SQLite include le seguenti tabelle:

#### 1.1 Utenti
```sql
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    chat_id TEXT,
    platform TEXT,
    language TEXT DEFAULT 'it',
    first_name TEXT,
    last_name TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

#### 1.2 Ordini
```sql
CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    status TEXT,
    delivery_method TEXT,
    delivery_address TEXT,
    payment_method TEXT,
    payment_status TEXT,
    total_amount REAL,
    items TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (user_id)
)
```

#### 1.3 Menu
```sql
CREATE TABLE menu_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT,
    name TEXT,
    description TEXT,
    price REAL,
    image_url TEXT,
    available BOOLEAN DEFAULT 1
)
```

#### 1.4 Sessioni
```sql
CREATE TABLE sessions (
    session_id TEXT PRIMARY KEY,
    user_id TEXT,
    state TEXT,
    data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (user_id)
)
```

### 2. Gestione Sessioni
- Ogni utente ha una sessione persistente
- Le sessioni memorizzano lo stato corrente e i dati temporanei
- I dati di sessione sono serializzati in JSON per la memorizzazione

## Integrazioni Esterne

### 1. Canali di Messaggistica
- **WhatsApp Business API**: Per comunicazione via WhatsApp
- **Telegram Bot API**: Per comunicazione via Telegram

### 2. Pagamenti
- **Stripe**: Per pagamenti con carta di credito/debito
- **Satispay**: Per pagamenti mobili

### 3. Menu
- **Google Sheets**: Per la gestione del menu
- **CMS Manus**: Alternativa per la gestione del menu

### 4. Notifiche
- **Webhook Telegram**: Per notifiche al proprietario
- **Email**: Per notifiche alternative

## Scalabilità e Estensioni Future

### 1. Scalabilità Orizzontale
- **Nuove Lingue**: La struttura del repository di traduzioni permette l'aggiunta di nuove lingue senza modificare il codice
- **Nuovi Canali**: L'architettura modulare consente l'aggiunta di nuovi canali di comunicazione

### 2. Scalabilità Verticale
- **Funzionalità AI**: Predisposizione per l'integrazione di webhook verso servizi AI
- **Sistemi di Pagamento**: Struttura flessibile per aggiungere nuovi gateway

### 3. Estensioni Pianificate
- **Programma Fedeltà**: Modulo aggiuntivo per gestire punti e premi
- **Sistema di Referral**: Tracciamento e ricompense per referral
- **Integrazione POS**: Connessione a sistemi di punto vendita

## Sicurezza

### 1. Protezione Dati
- Minimizzazione dei dati raccolti secondo GDPR
- Nessuna memorizzazione di dati sensibili di pagamento

### 2. Autenticazione
- Autenticazione basata su piattaforma (WhatsApp/Telegram)
- Sessioni sicure per ogni utente

## Istruzioni di Deployment

### 1. Requisiti
- Python 3.8+
- SQLite (per MVP) o PostgreSQL (per produzione)
- Accesso alle API di WhatsApp Business e Telegram
- Account Stripe e/o Satispay per pagamenti

### 2. Configurazione
1. Aggiornare `config.py` con i token API appropriati
2. Configurare il menu tramite Google Sheets o CMS Manus
3. Impostare i webhook per le notifiche

### 3. Deployment
1. Installare le dipendenze: `pip install -r requirements.txt`
2. Inizializzare il database: `python init_db.py`
3. Avviare il bot: `python main.py`

## Test e Validazione

Il sistema include una suite di test unitari che verificano:
- Funzionalità del gestore traduzioni
- Operazioni del gestore ordini
- Flussi di conversazione
- Rilevamento lingua

Per eseguire i test:
```
python -m unittest tests/test_validation.py
```

## Conclusioni

Il bot per pizzerie multilingua è stato progettato e implementato seguendo le migliori pratiche di sviluppo software, con particolare attenzione alla modularità, scalabilità e supporto multilingua. L'architettura permette facili estensioni future e l'aggiunta di nuove funzionalità senza modifiche significative al codice esistente.

---

# Appendice: Struttura dei File

```
/
├── src/
│   ├── config.py              # Configurazioni generali
│   ├── translations.py        # Gestore traduzioni
│   ├── database.py            # Interfaccia database
│   ├── order_manager.py       # Gestione ordini
│   ├── conversation_manager.py # Gestione conversazioni
│   └── main.py                # Punto di ingresso
├── tests/
│   └── test_validation.py     # Test unitari
├── data/
│   └── pizzabot.db            # Database SQLite
└── docs/
    ├── technical_doc.md       # Documentazione tecnica
    └── user_manual.md         # Manuale utente
```
