# Manuale Utente: Bot per Pizzerie Multilingua

## Introduzione

Benvenuti nel manuale utente del Bot per Pizzerie Multilingua! Questo bot è stato sviluppato per automatizzare e migliorare il processo di ordinazione nelle pizzerie, offrendo un'esperienza utente fluida in italiano, russo e inglese. Il bot funziona su WhatsApp e Telegram, permettendo ai clienti di ordinare pizze, bevande e menu combinati in modo semplice e intuitivo.

## Caratteristiche Principali

- **Supporto Multilingua**: Interfaccia completa in italiano, russo e inglese con rilevamento automatico della lingua
- **Menu Interattivo**: Visualizzazione di categorie e prodotti con descrizioni e prezzi
- **Gestione Carrello**: Aggiunta, rimozione e modifica degli elementi nel carrello
- **Opzioni di Consegna**: Scelta tra consegna a domicilio o ritiro in negozio
- **Pagamenti Online**: Integrazione con Stripe e Satispay per pagamenti sicuri
- **Notifiche**: Aggiornamenti automatici sullo stato dell'ordine
- **FAQ**: Risposte alle domande frequenti

## Guida Rapida all'Uso

### 1. Avvio del Bot

#### Su WhatsApp:
1. Salvare il numero del bot nei contatti
2. Aprire WhatsApp e iniziare una chat con il numero salvato
3. Inviare un messaggio di saluto o "/start" per iniziare

#### Su Telegram:
1. Cercare il nome del bot nella barra di ricerca di Telegram
2. Aprire la chat con il bot
3. Premere "Avvia" o inviare "/start" per iniziare

### 2. Navigazione del Menu

1. Dalla schermata di benvenuto, selezionare "Visualizza il menu"
2. Scegliere una categoria (Pizze, Bevande, Menu combinati)
3. Sfogliare i prodotti disponibili
4. Premere "Aggiungi" accanto ai prodotti desiderati
5. Utilizzare "Torna alle categorie" per cambiare categoria
6. Premere "Vai al carrello" quando si è pronti per ordinare

### 3. Gestione del Carrello

1. Nel carrello, visualizzare gli elementi selezionati e il totale
2. Utilizzare i pulsanti per:
   - Aggiungere altri prodotti
   - Rimuovere singoli elementi
   - Svuotare il carrello
   - Procedere all'ordine

### 4. Completamento dell'Ordine

1. Scegliere tra consegna a domicilio o ritiro in negozio
2. Se si sceglie la consegna, inserire l'indirizzo completo
3. Selezionare il metodo di pagamento preferito
4. Per pagamenti online, seguire il link fornito per completare la transazione
5. Ricevere la conferma dell'ordine con il riepilogo e il tempo stimato di consegna

### 5. Cambio Lingua

Il bot rileva automaticamente la lingua in base ai messaggi inviati. Per cambiare manualmente la lingua:
1. Digitare "/language" in qualsiasi momento
2. Selezionare la lingua desiderata tra italiano, russo e inglese

## Esempi di Utilizzo

### Esempio 1: Ordinare una Pizza Margherita con Consegna a Domicilio

1. Avviare il bot e selezionare "Ordina una pizza"
2. Scegliere la categoria "Pizze"
3. Selezionare "Margherita Aggiungi +"
4. Premere "Vai al carrello"
5. Premere "Procedi all'ordine"
6. Selezionare "Consegna a domicilio"
7. Inserire l'indirizzo: "Via Roma 123, Milano"
8. Confermare l'indirizzo
9. Scegliere "Carta di credito/debito"
10. Seguire il link di pagamento e completare la transazione
11. Ricevere la conferma dell'ordine

### Esempio 2: Ordinare un Menu Combinato con Ritiro in Negozio

1. Avviare il bot e selezionare "Visualizza il menu"
2. Scegliere la categoria "Menu combinati"
3. Selezionare "Menu Coppia Aggiungi +"
4. Premere "Vai al carrello"
5. Premere "Procedi all'ordine"
6. Selezionare "Ritiro in negozio"
7. Scegliere "Contanti alla consegna"
8. Ricevere la conferma dell'ordine con istruzioni per il ritiro

## FAQ

### Domande Generali

**D: Quali sono gli orari di apertura?**  
R: Siamo aperti tutti i giorni dalle 11:00 alle 23:00. Venerdì e sabato restiamo aperti fino alle 00:00.

**D: Quali sono le zone di consegna?**  
R: Consegniamo in tutta la città e nei comuni limitrofi entro 10 km dal nostro locale.

**D: Quanto tempo ci vuole per la consegna?**  
R: Il tempo di consegna stimato è di 30-40 minuti, a seconda della distanza e del traffico.

**D: Ci sono informazioni sugli allergeni?**  
R: Utilizziamo solo ingredienti freschi e di alta qualità. Per informazioni sugli allergeni, consulta la descrizione di ciascun prodotto nel menu o contattaci direttamente.

### Problemi Tecnici

**D: Il bot non risponde, cosa devo fare?**  
R: Prova a inviare nuovamente "/start" o a riavviare l'applicazione di messaggistica.

**D: Come posso annullare un ordine?**  
R: Seleziona "Contatta il ristorante" dalla schermata di conferma dell'ordine e comunica la tua richiesta di annullamento.

**D: Non riesco a completare il pagamento, cosa devo fare?**  
R: Verifica che i dati della carta siano corretti. Se il problema persiste, seleziona un metodo di pagamento alternativo o contatta il ristorante.

## Contatti e Supporto

Per assistenza o informazioni aggiuntive:
- **Telefono**: +39 123 456 7890
- **Email**: info@pizzeria.com
- **Indirizzo**: Via Roma 123, Milano

## Istruzioni per il Proprietario

### Gestione del Menu

Il menu può essere aggiornato facilmente tramite Google Sheets:
1. Accedere al foglio Google condiviso
2. Modificare i prodotti, prezzi o descrizioni
3. Le modifiche saranno sincronizzate automaticamente con il bot

### Notifiche degli Ordini

Quando un cliente effettua un ordine:
1. Riceverai una notifica su Telegram con tutti i dettagli
2. In alternativa, riceverai un'email con il riepilogo dell'ordine
3. Puoi confermare la ricezione dell'ordine direttamente dalla notifica

### Monitoraggio e Statistiche

Per accedere alle statistiche e ai report:
1. Accedere al pannello di amministrazione
2. Visualizzare i dati sugli ordini, prodotti più venduti e feedback dei clienti
3. Esportare i report in formato CSV o PDF per ulteriori analisi

---

Grazie per aver scelto il nostro Bot per Pizzerie Multilingua! Per qualsiasi domanda o suggerimento, non esitate a contattarci.
