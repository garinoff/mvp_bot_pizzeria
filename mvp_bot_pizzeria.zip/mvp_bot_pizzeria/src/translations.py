"""
Gestione delle traduzioni per il bot pizzeria
"""

class TranslationManager:
    """
    Gestisce le traduzioni per il bot pizzeria in italiano, russo e inglese.
    """
    
    def __init__(self, default_language="it"):
        """
        Inizializza il gestore delle traduzioni.
        
        Args:
            default_language (str): Lingua predefinita (it, ru, en)
        """
        self.default_language = default_language
        self.translations = self._load_translations()
        
    def _load_translations(self):
        """
        Carica le traduzioni da un dizionario.
        In un'implementazione reale, queste potrebbero essere caricate da un file JSON o database.
        
        Returns:
            dict: Dizionario delle traduzioni
        """
        return {
            # Scene 1: Benvenuto
            "welcome": {
                "message": {
                    "it": "Ciao 👋 Benvenuto nella nostra pizzeria! Come posso aiutarti oggi?",
                    "ru": "Привет 👋 Добро пожаловать в нашу пиццерию! Чем я могу вам помочь?",
                    "en": "Hello 👋 Welcome to our pizzeria! How can I help you today?"
                },
                "buttons": {
                    "order": {
                        "it": "Ordina una pizza 🍕",
                        "ru": "Заказать пиццу 🍕",
                        "en": "Order a pizza 🍕"
                    },
                    "menu": {
                        "it": "Visualizza il menu 📋",
                        "ru": "Посмотреть меню 📋",
                        "en": "View menu 📋"
                    },
                    "repeat": {
                        "it": "Ripeti l'ultimo ordine 🔁",
                        "ru": "Повторить заказ 🔁",
                        "en": "Repeat last order 🔁"
                    },
                    "faq": {
                        "it": "Domande frequenti ❓",
                        "ru": "Задать вопрос ❓",
                        "en": "Ask a question ❓"
                    }
                }
            },
            
            # Scene 2: Menu
            "menu": {
                "intro": {
                    "it": "Ecco il nostro menu. Cosa ti piacerebbe ordinare oggi?",
                    "ru": "Вот наше меню. Что бы вы хотели заказать сегодня?",
                    "en": "Here's our menu. What would you like to order today?"
                },
                "categories": {
                    "pizzas": {
                        "it": "Pizze 🍕",
                        "ru": "Пиццы 🍕",
                        "en": "Pizzas 🍕"
                    },
                    "drinks": {
                        "it": "Bevande 🥤",
                        "ru": "Напитки 🥤",
                        "en": "Drinks 🥤"
                    },
                    "combos": {
                        "it": "Menu combinati 🍽️",
                        "ru": "Комбо-меню 🍽️",
                        "en": "Combo meals 🍽️"
                    }
                },
                "category_intro": {
                    "pizzas": {
                        "it": "Ecco le nostre pizze:",
                        "ru": "Вот наши пиццы:",
                        "en": "Here are our pizzas:"
                    },
                    "drinks": {
                        "it": "Ecco le nostre bevande:",
                        "ru": "Вот наши напитки:",
                        "en": "Here are our drinks:"
                    },
                    "combos": {
                        "it": "Ecco i nostri menu combinati:",
                        "ru": "Вот наши комбо-меню:",
                        "en": "Here are our combo meals:"
                    }
                },
                "buttons": {
                    "add": {
                        "it": "Aggiungi +",
                        "ru": "Добавить +",
                        "en": "Add +"
                    },
                    "back": {
                        "it": "Torna alle categorie ↩️",
                        "ru": "Вернуться к категориям ↩️",
                        "en": "Back to categories ↩️"
                    },
                    "cart": {
                        "it": "Vai al carrello 🛒",
                        "ru": "Перейти в корзину 🛒",
                        "en": "Go to cart 🛒"
                    }
                }
            },
            
            # Scene 3: Carrello
            "cart": {
                "intro": {
                    "it": "Ecco il tuo carrello attuale:",
                    "ru": "Вот ваша текущая корзина:",
                    "en": "Here's your current cart:"
                },
                "empty": {
                    "it": "Il tuo carrello è vuoto. Aggiungi qualcosa dal menu!",
                    "ru": "Ваша корзина пуста. Добавьте что-нибудь из меню!",
                    "en": "Your cart is empty. Add something from the menu!"
                },
                "total": {
                    "it": "Totale: {total}",
                    "ru": "Итого: {total}",
                    "en": "Total: {total}"
                },
                "buttons": {
                    "add_more": {
                        "it": "Aggiungi altri prodotti ➕",
                        "ru": "Добавить еще ➕",
                        "en": "Add more items ➕"
                    },
                    "clear": {
                        "it": "Svuota carrello 🗑️",
                        "ru": "Очистить корзину 🗑️",
                        "en": "Empty cart 🗑️"
                    },
                    "checkout": {
                        "it": "Procedi all'ordine ✅",
                        "ru": "Оформить заказ ✅",
                        "en": "Proceed to checkout ✅"
                    }
                }
            },
            
            # Scene 4: Consegna
            "delivery": {
                "method_question": {
                    "it": "Come preferisci ricevere il tuo ordine?",
                    "ru": "Как вы хотите получить ваш заказ?",
                    "en": "How would you like to receive your order?"
                },
                "buttons": {
                    "delivery": {
                        "it": "Consegna a domicilio 🚗",
                        "ru": "Доставка 🚗",
                        "en": "Home delivery 🚗"
                    },
                    "pickup": {
                        "it": "Ritiro in negozio 🏃",
                        "ru": "Самовывоз 🏃",
                        "en": "Pick up in store 🏃"
                    }
                },
                "address_request": {
                    "it": "Per favore, inserisci l'indirizzo di consegna completo (via, numero civico, città e CAP):",
                    "ru": "Пожалуйста, введите полный адрес доставки (улица, номер дома, квартира, город):",
                    "en": "Please enter your complete delivery address (street, number, city and postal code):"
                },
                "address_confirm": {
                    "it": "Grazie! L'indirizzo di consegna è: {address}. È corretto?",
                    "ru": "Спасибо! Адрес доставки: {address}. Всё верно?",
                    "en": "Thank you! The delivery address is: {address}. Is this correct?"
                },
                "buttons_confirm": {
                    "yes": {
                        "it": "Sì, è corretto ✅",
                        "ru": "Да, верно ✅",
                        "en": "Yes, it's correct ✅"
                    },
                    "no": {
                        "it": "No, voglio modificarlo ✏️",
                        "ru": "Нет, изменить ✏️",
                        "en": "No, I want to change it ✏️"
                    }
                },
                "pickup_confirm": {
                    "it": "Hai scelto il ritiro in negozio. Il tuo ordine sarà pronto per il ritiro presso il nostro locale in Via Roma 123.",
                    "ru": "Вы выбрали самовывоз. Ваш заказ будет готов к получению в нашем ресторане по адресу Улица Ленина 123.",
                    "en": "You've chosen store pickup. Your order will be ready for collection at our store on 123 Main Street."
                }
            },
            
            # Scene 5: Pagamento
            "payment": {
                "method_question": {
                    "it": "Il tuo ordine è quasi pronto! Scegli il metodo di pagamento:",
                    "ru": "Ваш заказ почти готов! Выберите способ оплаты:",
                    "en": "Your order is almost ready! Choose your payment method:"
                },
                "buttons": {
                    "card": {
                        "it": "Carta di credito/debito 💳",
                        "ru": "Банковская карта 💳",
                        "en": "Credit/debit card 💳"
                    },
                    "satispay": {
                        "it": "Satispay 📱",
                        "ru": "Satispay 📱",
                        "en": "Satispay 📱"
                    },
                    "cash": {
                        "it": "Contanti alla consegna 💶",
                        "ru": "Наличные при получении 💶",
                        "en": "Cash on delivery 💶"
                    }
                },
                "payment_link": {
                    "it": "Perfetto! Ecco il link per completare il pagamento: {link}\nClicca sul link e segui le istruzioni per completare la transazione.",
                    "ru": "Отлично! Вот ссылка для завершения оплаты: {link}\nНажмите на ссылку и следуйте инструкциям для завершения транзакции.",
                    "en": "Perfect! Here's the link to complete your payment: {link}\nClick on the link and follow the instructions to complete the transaction."
                },
                "payment_confirmed": {
                    "it": "Pagamento ricevuto con successo! Grazie.",
                    "ru": "Оплата успешно получена! Спасибо.",
                    "en": "Payment successfully received! Thank you."
                },
                "cash_confirmed": {
                    "it": "Hai scelto di pagare in contanti alla consegna. Preparati a pagare {total} al momento della consegna.",
                    "ru": "Вы выбрали оплату наличными при получении. Приготовьте {total} для оплаты при доставке.",
                    "en": "You've chosen to pay cash on delivery. Please prepare {total} to pay upon delivery."
                }
            },
            
            # Scene 6: Conferma
            "confirmation": {
                "thank_you": {
                    "it": "Grazie per il tuo ordine! 🎉",
                    "ru": "Спасибо за ваш заказ! 🎉",
                    "en": "Thank you for your order! 🎉"
                },
                "order_summary": {
                    "it": "Riepilogo ordine #{order_id}:",
                    "ru": "Сводка заказа #{order_id}:",
                    "en": "Order summary #{order_id}:"
                },
                "preparation_message": {
                    "it": "La tua pizza è in preparazione e sarà pronta tra 30-40 minuti.\nTi invieremo una notifica quando il tuo ordine sarà in consegna. 🍕",
                    "ru": "Ваша пицца готовится и будет готова через 30-40 минут.\nМы отправим вам уведомление, когда ваш заказ будет в пути. 🍕",
                    "en": "Your pizza is being prepared and will be ready in 30-40 minutes.\nWe'll send you a notification when your order is out for delivery. 🍕"
                },
                "buttons": {
                    "track": {
                        "it": "Traccia il mio ordine 🔍",
                        "ru": "Отследить мой заказ 🔍",
                        "en": "Track my order 🔍"
                    },
                    "contact": {
                        "it": "Contatta il ristorante 📞",
                        "ru": "Связаться с рестораном 📞",
                        "en": "Contact the restaurant 📞"
                    },
                    "home": {
                        "it": "Torna al menu principale 🏠",
                        "ru": "Вернуться в главное меню 🏠",
                        "en": "Return to main menu 🏠"
                    }
                }
            },
            
            # Scene Aggiuntiva: FAQ
            "faq": {
                "intro": {
                    "it": "Ecco alcune domande frequenti. Cosa vorresti sapere?",
                    "ru": "Вот некоторые часто задаваемые вопросы. Что бы вы хотели узнать?",
                    "en": "Here are some frequently asked questions. What would you like to know?"
                },
                "buttons": {
                    "hours": {
                        "it": "Orari di apertura ⏰",
                        "ru": "Часы работы ⏰",
                        "en": "Opening hours ⏰"
                    },
                    "areas": {
                        "it": "Zone di consegna 🗺️",
                        "ru": "Зоны доставки 🗺️",
                        "en": "Delivery areas 🗺️"
                    },
                    "time": {
                        "it": "Tempo di consegna stimato ⏱️",
                        "ru": "Расчетное время доставки ⏱️",
                        "en": "Estimated delivery time ⏱️"
                    },
                    "ingredients": {
                        "it": "Ingredienti e allergeni 🌱",
                        "ru": "Ингредиенты и аллергены 🌱",
                        "en": "Ingredients and allergens 🌱"
                    },
                    "home": {
                        "it": "Torna al menu principale 🏠",
                        "ru": "Вернуться в главное меню 🏠",
                        "en": "Return to main menu 🏠"
                    }
                },
                "answers": {
                    "hours": {
                        "it": "Siamo aperti tutti i giorni dalle 11:00 alle 23:00.\nVenerdì e sabato restiamo aperti fino alle 00:00.",
                        "ru": "Мы открыты ежедневно с 11:00 до 23:00.\nПо пятницам и субботам мы работаем до 00:00.",
                        "en": "We are open every day from 11:00 AM to 11:00 PM.\nOn Fridays and Saturdays we stay open until midnight."
                    },
                    "areas": {
                        "it": "Consegniamo in tutta la città e nei comuni limitrofi entro 10 km dal nostro locale.",
                        "ru": "Мы доставляем по всему городу и в близлежащие районы в радиусе 10 км от нашего ресторана.",
                        "en": "We deliver throughout the city and to neighboring areas within 10 km of our restaurant."
                    },
                    "time": {
                        "it": "Il tempo di consegna stimato è di 30-40 minuti, a seconda della distanza e del traffico.",
                        "ru": "Расчетное время доставки составляет 30-40 минут, в зависимости от расстояния и загруженности дорог.",
                        "en": "The estimated delivery time is 30-40 minutes, depending on distance and traffic."
                    },
                    "ingredients": {
                        "it": "Utilizziamo solo ingredienti freschi e di alta qualità. Per informazioni sugli allergeni, consulta la descrizione di ciascun prodotto nel menu o contattaci direttamente.",
                        "ru": "Мы используем только свежие и качественные ингредиенты. Для получения информации об аллергенах, пожалуйста, ознакомьтесь с описанием каждого продукта в меню или свяжитесь с нами напрямую.",
                        "en": "We use only fresh, high-quality ingredients. For allergen information, please check the description of each product in the menu or contact us directly."
                    }
                }
            },
            
            # Messaggi generici
            "generic": {
                "error": {
                    "it": "Mi dispiace, si è verificato un errore. Riprova più tardi.",
                    "ru": "Извините, произошла ошибка. Пожалуйста, повторите попытку позже.",
                    "en": "Sorry, an error occurred. Please try again later."
                },
                "back": {
                    "it": "Indietro",
                    "ru": "Назад",
                    "en": "Back"
                },
                "cancel": {
                    "it": "Annulla",
                    "ru": "Отмена",
                    "en": "Cancel"
                },
                "next": {
                    "it": "Avanti",
                    "ru": "Далее",
                    "en": "Next"
                },
                "select_language": {
                    "it": "Seleziona la lingua:",
                    "ru": "Выберите язык:",
                    "en": "Select language:"
                },
                "language_changed": {
                    "it": "Lingua cambiata in italiano!",
                    "ru": "Язык изменен на русский!",
                    "en": "Language changed to English!"
                }
            }
        }
    
    def get_text(self, key_path, language=None):
        """
        Ottiene il testo tradotto per una chiave specifica.
        
        Args:
            key_path (str): Percorso della chiave (es. "welcome.message")
            language (str, optional): Lingua desiderata. Se None, usa la lingua predefinita.
            
        Returns:
            str: Testo tradotto
        """
        if language is None:
            language = self.default_language
            
        # Assicurati che la lingua sia supportata
        if language not in ["it", "ru", "en"]:
            language = self.default_language
            
        # Dividi il percorso della chiave
        keys = key_path.split(".")
        
        # Naviga nel dizionario delle traduzioni
        current = self.translations
        for key in keys:
            if key in current:
                current = current[key]
            else:
                return f"[Missing translation: {key_path}]"
        
        # Ottieni la traduzione nella lingua specificata
        if language in current:
            return current[language]
        elif self.default_language in current:
            # Fallback alla lingua predefinita
            return current[self.default_language]
        else:
            # Fallback alla prima lingua disponibile
            for lang in ["it", "en", "ru"]:
                if lang in current:
                    return current[lang]
            
            return f"[Missing translation: {key_path}]"
    
    def format_currency(self, amount, language=None):
        """
        Formatta un importo di valuta in base alla lingua.
        
        Args:
            amount (float): Importo da formattare
            language (str, optional): Lingua desiderata
            
        Returns:
            str: Importo formattato
        """
        if language is None:
            language = self.default_language
            
        if language == "ru":
            # Formato russo (rubli)
            return f"{amount}₽"
        else:
            # Formato italiano/inglese (euro)
            return f"€{amount:.2f}"
    
    def detect_language(self, text):
        """
        Rileva la lingua del testo (implementazione semplificata).
        In un'implementazione reale, si utilizzerebbe una libreria di rilevamento lingua.
        
        Args:
            text (str): Testo da analizzare
            
        Returns:
            str: Codice lingua rilevato
        """
        # Caratteri cirillici per il russo
        cyrillic = set("абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
        
        # Caratteri speciali italiani
        italian_special = set("àèéìòù")
        
        # Parole comuni italiane per migliorare il rilevamento
        italian_words = ["ciao", "pizza", "vorrei", "grazie", "per", "una", "della", "come", "sono", "che", "non", "mi", "ti", "si", "e", "il", "la", "lo", "gli", "le"]
        
        # Parole comuni inglesi per migliorare il rilevamento
        english_words = ["hello", "hi", "would", "like", "please", "thank", "you", "the", "and", "order", "pizza", "want", "to", "for", "me", "my", "is", "are", "what", "where"]
        
        # Conta i caratteri
        text_lower = text.lower()
        cyrillic_count = sum(1 for char in text_lower if char in cyrillic)
        italian_count = sum(1 for char in text_lower if char in italian_special)
        
        # Controlla parole comuni
        words = text_lower.split()
        italian_word_count = sum(1 for word in words if word in italian_words)
        english_word_count = sum(1 for word in words if word in english_words)
        
        # Determina la lingua in base ai caratteri e alle parole
        if cyrillic_count > 0:
            return "ru"
        elif italian_count > 0 or (italian_word_count > 0 and italian_word_count >= english_word_count):
            return "it"
        elif english_word_count > 0:
            return "en"
        else:
            # Fallback all'inglese se non ci sono caratteri specifici o parole riconosciute
            return "en"
