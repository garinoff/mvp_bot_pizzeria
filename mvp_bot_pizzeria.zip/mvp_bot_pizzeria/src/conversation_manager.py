"""
Gestore delle conversazioni per il bot pizzeria
"""

import uuid
from datetime import datetime

class ConversationManager:
    """
    Gestisce le conversazioni e i flussi di dialogo per il bot pizzeria.
    """
    
    def __init__(self, database, translation_manager, order_manager):
        """
        Inizializza il gestore delle conversazioni.
        
        Args:
            database: Istanza del database
            translation_manager: Gestore delle traduzioni
            order_manager: Gestore degli ordini
        """
        self.db = database
        self.translator = translation_manager
        self.order_manager = order_manager
        
        # Stati della conversazione
        self.STATES = {
            "WELCOME": "welcome",
            "MENU_CATEGORIES": "menu_categories",
            "MENU_ITEMS": "menu_items",
            "CART": "cart",
            "DELIVERY_METHOD": "delivery_method",
            "DELIVERY_ADDRESS": "delivery_address",
            "PAYMENT_METHOD": "payment_method",
            "PAYMENT_PROCESSING": "payment_processing",
            "ORDER_CONFIRMATION": "order_confirmation",
            "FAQ": "faq",
            "FAQ_ANSWER": "faq_answer"
        }
    
    def get_session(self, user_id, platform, chat_id):
        """
        Ottiene o crea una sessione per un utente.
        
        Args:
            user_id (str): ID utente
            platform (str): Piattaforma (telegram, whatsapp)
            chat_id (str): ID chat
            
        Returns:
            tuple: (session_id, session_data, state, user_language)
        """
        # Ottieni o crea l'utente
        user = self.db.get_user(user_id, platform)
        if not user:
            user = self.db.create_or_update_user(user_id, platform, chat_id)
        
        # Genera un ID sessione univoco
        session_id = f"{platform}_{user_id}"
        
        # Ottieni o crea la sessione
        session = self.db.get_session(session_id)
        if not session:
            session = self.db.create_or_update_session(
                session_id=session_id,
                user_id=user_id,
                state=self.STATES["WELCOME"],
                data={}
            )
        
        return session_id, session['data'], session['state'], user['language']
    
    def update_session(self, session_id, state, data):
        """
        Aggiorna lo stato e i dati di una sessione.
        
        Args:
            session_id (str): ID sessione
            state (str): Nuovo stato
            data (dict): Nuovi dati
            
        Returns:
            dict: Sessione aggiornata
        """
        return self.db.create_or_update_session(session_id, None, state, data)
    
    def handle_message(self, user_id, platform, chat_id, message_text, callback_data=None):
        """
        Gestisce un messaggio in arrivo.
        
        Args:
            user_id (str): ID utente
            platform (str): Piattaforma (telegram, whatsapp)
            chat_id (str): ID chat
            message_text (str): Testo del messaggio
            callback_data (str, optional): Dati di callback (per i pulsanti)
            
        Returns:
            dict: Risposta da inviare all'utente
        """
        # Ottieni la sessione
        session_id, session_data, state, user_language = self.get_session(user_id, platform, chat_id)
        
        # Rileva la lingua se non specificata
        if message_text and not callback_data:
            detected_language = self.translator.detect_language(message_text)
            if detected_language != user_language:
                user_language = detected_language
                self.db.update_user_language(user_id, platform, user_language)
        
        # Gestisci i comandi globali
        if message_text and message_text.startswith("/"):
            response = self._handle_command(message_text, user_language)
            if response:
                return response
        
        # Gestisci lo stato corrente
        response = self._handle_state(state, session_data, message_text, callback_data, user_language, user_id)
        
        # Aggiorna la sessione con i nuovi dati
        self.update_session(session_id, response["next_state"], session_data)
        
        return {
            "text": response["text"],
            "buttons": response["buttons"],
            "next_state": response["next_state"]
        }
    
    def _handle_command(self, message_text, language):
        """
        Gestisce i comandi globali.
        
        Args:
            message_text (str): Testo del messaggio
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta o None se non è un comando
        """
        if message_text == "/start" or message_text == "/help":
            return self._get_welcome_response(language)
        elif message_text == "/menu":
            return self._get_menu_categories_response(language)
        elif message_text == "/cart":
            return self._get_cart_response({}, language)
        elif message_text == "/language":
            return self._get_language_selection_response(language)
        
        return None
    
    def _handle_state(self, state, session_data, message_text, callback_data, language, user_id):
        """
        Gestisce lo stato corrente della conversazione.
        
        Args:
            state (str): Stato corrente
            session_data (dict): Dati della sessione
            message_text (str): Testo del messaggio
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            user_id (str): ID utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        # Gestisci in base allo stato
        if state == self.STATES["WELCOME"]:
            return self._handle_welcome_state(callback_data, language)
        elif state == self.STATES["MENU_CATEGORIES"]:
            return self._handle_menu_categories_state(callback_data, language)
        elif state == self.STATES["MENU_ITEMS"]:
            return self._handle_menu_items_state(session_data, callback_data, language)
        elif state == self.STATES["CART"]:
            return self._handle_cart_state(session_data, callback_data, language)
        elif state == self.STATES["DELIVERY_METHOD"]:
            return self._handle_delivery_method_state(session_data, callback_data, language)
        elif state == self.STATES["DELIVERY_ADDRESS"]:
            return self._handle_delivery_address_state(session_data, message_text, callback_data, language)
        elif state == self.STATES["PAYMENT_METHOD"]:
            return self._handle_payment_method_state(session_data, callback_data, language)
        elif state == self.STATES["PAYMENT_PROCESSING"]:
            return self._handle_payment_processing_state(session_data, callback_data, language)
        elif state == self.STATES["ORDER_CONFIRMATION"]:
            return self._handle_order_confirmation_state(session_data, callback_data, language)
        elif state == self.STATES["FAQ"]:
            return self._handle_faq_state(callback_data, language)
        elif state == self.STATES["FAQ_ANSWER"]:
            return self._handle_faq_answer_state(session_data, callback_data, language)
        else:
            # Stato sconosciuto, torna al benvenuto
            return self._get_welcome_response(language)
    
    def _handle_welcome_state(self, callback_data, language):
        """
        Gestisce lo stato di benvenuto.
        
        Args:
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "order":
            return self._get_menu_categories_response(language)
        elif callback_data == "menu":
            return self._get_menu_categories_response(language)
        elif callback_data == "repeat":
            # In un'implementazione reale, qui si recupererebbe l'ultimo ordine
            return self._get_cart_response({}, language)
        elif callback_data == "faq":
            return self._get_faq_response(language)
        else:
            return self._get_welcome_response(language)
    
    def _handle_menu_categories_state(self, callback_data, language):
        """
        Gestisce lo stato delle categorie del menu.
        
        Args:
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data in ["pizzas", "drinks", "combos"]:
            return self._get_menu_items_response(callback_data, language)
        elif callback_data == "cart":
            return self._get_cart_response({}, language)
        elif callback_data == "back":
            return self._get_welcome_response(language)
        else:
            return self._get_menu_categories_response(language)
    
    def _handle_menu_items_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato degli elementi del menu.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data and callback_data.startswith("add_"):
            # Aggiungi al carrello
            item_id = int(callback_data.split("_")[1])
            self.order_manager.add_to_cart(session_data, item_id)
            
            # Rimani nella stessa categoria
            category = session_data.get("current_category", "pizzas")
            return self._get_menu_items_response(category, language)
        elif callback_data == "back":
            return self._get_menu_categories_response(language)
        elif callback_data == "cart":
            return self._get_cart_response(session_data, language)
        else:
            # Rimani nella stessa categoria
            category = session_data.get("current_category", "pizzas")
            return self._get_menu_items_response(category, language)
    
    def _handle_cart_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato del carrello.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "add_more":
            return self._get_menu_categories_response(language)
        elif callback_data == "clear":
            self.order_manager.clear_cart(session_data)
            return self._get_cart_response(session_data, language)
        elif callback_data == "checkout":
            if 'cart' in session_data and session_data['cart']['items']:
                return self._get_delivery_method_response(language)
            else:
                return self._get_cart_response(session_data, language)
        elif callback_data and callback_data.startswith("remove_"):
            # Rimuovi dal carrello
            item_id = int(callback_data.split("_")[1])
            self.order_manager.remove_from_cart(session_data, item_id)
            return self._get_cart_response(session_data, language)
        else:
            return self._get_cart_response(session_data, language)
    
    def _handle_delivery_method_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato del metodo di consegna.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "delivery":
            session_data["delivery_method"] = "delivery"
            return self._get_delivery_address_request_response(language)
        elif callback_data == "pickup":
            session_data["delivery_method"] = "pickup"
            # Salta l'inserimento dell'indirizzo
            return self._get_payment_method_response(language)
        else:
            return self._get_delivery_method_response(language)
    
    def _handle_delivery_address_state(self, session_data, message_text, callback_data, language):
        """
        Gestisce lo stato dell'indirizzo di consegna.
        
        Args:
            session_data (dict): Dati della sessione
            message_text (str): Testo del messaggio
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "yes":
            # Conferma indirizzo
            return self._get_payment_method_response(language)
        elif callback_data == "no":
            # Richiedi nuovamente l'indirizzo
            return self._get_delivery_address_request_response(language)
        elif message_text:
            # Salva l'indirizzo e chiedi conferma
            session_data["delivery_address"] = message_text
            return self._get_delivery_address_confirm_response(session_data, language)
        else:
            return self._get_delivery_address_request_response(language)
    
    def _handle_payment_method_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato del metodo di pagamento.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data in ["card", "satispay"]:
            session_data["payment_method"] = callback_data
            return self._get_payment_link_response(session_data, language)
        elif callback_data == "cash":
            session_data["payment_method"] = "cash"
            # Salta il processo di pagamento online
            return self._get_cash_payment_response(session_data, language)
        else:
            return self._get_payment_method_response(language)
    
    def _handle_payment_processing_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato di elaborazione del pagamento.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "paid":
            # Simula il completamento del pagamento
            if "order_id" in session_data:
                self.order_manager.update_payment_status(session_data["order_id"], "completed")
            
            return self._get_order_confirmation_response(session_data, language)
        else:
            return self._get_payment_link_response(session_data, language)
    
    def _handle_order_confirmation_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato di conferma dell'ordine.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "track":
            # In un'implementazione reale, qui si mostrerebbe lo stato dell'ordine
            return self._get_order_confirmation_response(session_data, language)
        elif callback_data == "contact":
            # In un'implementazione reale, qui si fornirebbe un contatto
            return self._get_contact_info_response(language)
        elif callback_data == "home":
            return self._get_welcome_response(language)
        else:
            return self._get_order_confirmation_response(session_data, language)
    
    def _handle_faq_state(self, callback_data, language):
        """
        Gestisce lo stato delle FAQ.
        
        Args:
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data in ["hours", "areas", "time", "ingredients"]:
            return self._get_faq_answer_response(callback_data, language)
        elif callback_data == "home":
            return self._get_welcome_response(language)
        else:
            return self._get_faq_response(language)
    
    def _handle_faq_answer_state(self, session_data, callback_data, language):
        """
        Gestisce lo stato delle risposte alle FAQ.
        
        Args:
            session_data (dict): Dati della sessione
            callback_data (str): Dati di callback
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta e prossimo stato
        """
        if callback_data == "back":
            return self._get_faq_response(language)
        elif callback_data == "home":
            return self._get_welcome_response(language)
        else:
            # Rimani nella stessa risposta
            faq_topic = session_data.get("faq_topic", "hours")
            return self._get_faq_answer_response(faq_topic, language)
    
    # Metodi per generare risposte
    
    def _get_welcome_response(self, language):
        """
        Genera la risposta di benvenuto.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("welcome.message", language)
        buttons = [
            {
                "text": self.translator.get_text("welcome.buttons.order", language),
                "callback_data": "order"
            },
            {
                "text": self.translator.get_text("welcome.buttons.menu", language),
                "callback_data": "menu"
            },
            {
                "text": self.translator.get_text("welcome.buttons.repeat", language),
                "callback_data": "repeat"
            },
            {
                "text": self.translator.get_text("welcome.buttons.faq", language),
                "callback_data": "faq"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["WELCOME"]
        }
    
    def _get_menu_categories_response(self, language):
        """
        Genera la risposta con le categorie del menu.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("menu.intro", language)
        buttons = [
            {
                "text": self.translator.get_text("menu.categories.pizzas", language),
                "callback_data": "pizzas"
            },
            {
                "text": self.translator.get_text("menu.categories.drinks", language),
                "callback_data": "drinks"
            },
            {
                "text": self.translator.get_text("menu.categories.combos", language),
                "callback_data": "combos"
            },
            {
                "text": self.translator.get_text("menu.buttons.cart", language),
                "callback_data": "cart"
            },
            {
                "text": self.translator.get_text("generic.back", language),
                "callback_data": "back"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["MENU_CATEGORIES"]
        }
    
    def _get_menu_items_response(self, category, language):
        """
        Genera la risposta con gli elementi del menu di una categoria.
        
        Args:
            category (str): Categoria
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        # In un'implementazione reale, qui si otterrebbero gli elementi dal database
        # Per l'MVP, utilizziamo un menu di esempio
        menu_items = []
        if category == "pizzas":
            menu_items = [
                {"item_id": 1, "name": "Margherita", "price": 8.0, "description": "Pomodoro, mozzarella, basilico"},
                {"item_id": 2, "name": "Diavola", "price": 10.0, "description": "Pomodoro, mozzarella, salame piccante"},
                {"item_id": 3, "name": "Quattro Formaggi", "price": 11.0, "description": "Mozzarella, gorgonzola, fontina, parmigiano"}
            ]
        elif category == "drinks":
            menu_items = [
                {"item_id": 4, "name": "Coca Cola 0.5L", "price": 2.5, "description": ""},
                {"item_id": 5, "name": "Acqua 0.5L", "price": 1.5, "description": ""},
                {"item_id": 6, "name": "Birra 0.33L", "price": 3.5, "description": ""}
            ]
        elif category == "combos":
            menu_items = [
                {"item_id": 7, "name": "Menu Coppia", "price": 20.0, "description": "2 pizze + 2 bevande"},
                {"item_id": 8, "name": "Menu Famiglia", "price": 30.0, "description": "3 pizze + 3 bevande + 1 dolce"}
            ]
        
        text = self.translator.get_text(f"menu.category_intro.{category}", language) + "\n\n"
        
        # Aggiungi gli elementi del menu al testo
        for item in menu_items:
            price_formatted = self.translator.format_currency(item["price"], language)
            if item["description"]:
                text += f"{item['name']} - {item['description']} - {price_formatted}\n"
            else:
                text += f"{item['name']} - {price_formatted}\n"
        
        # Pulsanti per aggiungere al carrello
        buttons = []
        for item in menu_items:
            add_text = self.translator.get_text("menu.buttons.add", language)
            buttons.append({
                "text": f"{item['name']} {add_text}",
                "callback_data": f"add_{item['item_id']}"
            })
        
        # Pulsanti di navigazione
        buttons.extend([
            {
                "text": self.translator.get_text("menu.buttons.back", language),
                "callback_data": "back"
            },
            {
                "text": self.translator.get_text("menu.buttons.cart", language),
                "callback_data": "cart"
            }
        ])
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["MENU_ITEMS"]
        }
    
    def _get_cart_response(self, session_data, language):
        """
        Genera la risposta con il contenuto del carrello.
        
        Args:
            session_data (dict): Dati della sessione
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        # Assicurati che il carrello esista
        session_data = self.order_manager.create_cart(session_data)
        
        # Ottieni il riepilogo del carrello
        cart_summary = self.order_manager.get_cart_summary(session_data, language)
        
        # Pulsanti
        buttons = []
        
        # Se il carrello non è vuoto, aggiungi pulsanti per la gestione
        if 'cart' in session_data and session_data['cart']['items']:
            buttons = [
                {
                    "text": self.translator.get_text("cart.buttons.add_more", language),
                    "callback_data": "add_more"
                },
                {
                    "text": self.translator.get_text("cart.buttons.clear", language),
                    "callback_data": "clear"
                },
                {
                    "text": self.translator.get_text("cart.buttons.checkout", language),
                    "callback_data": "checkout"
                }
            ]
            
            # Aggiungi pulsanti per rimuovere singoli elementi
            for item in session_data['cart']['items']:
                buttons.append({
                    "text": f"❌ {item['name']}",
                    "callback_data": f"remove_{item['item_id']}"
                })
        else:
            # Carrello vuoto, mostra solo il pulsante per aggiungere
            buttons = [
                {
                    "text": self.translator.get_text("cart.buttons.add_more", language),
                    "callback_data": "add_more"
                }
            ]
        
        return {
            "text": cart_summary,
            "buttons": buttons,
            "next_state": self.STATES["CART"]
        }
    
    def _get_delivery_method_response(self, language):
        """
        Genera la risposta per la scelta del metodo di consegna.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("delivery.method_question", language)
        buttons = [
            {
                "text": self.translator.get_text("delivery.buttons.delivery", language),
                "callback_data": "delivery"
            },
            {
                "text": self.translator.get_text("delivery.buttons.pickup", language),
                "callback_data": "pickup"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["DELIVERY_METHOD"]
        }
    
    def _get_delivery_address_request_response(self, language):
        """
        Genera la risposta per la richiesta dell'indirizzo di consegna.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("delivery.address_request", language)
        buttons = []  # Nessun pulsante, l'utente deve inserire l'indirizzo
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["DELIVERY_ADDRESS"]
        }
    
    def _get_delivery_address_confirm_response(self, session_data, language):
        """
        Genera la risposta per la conferma dell'indirizzo di consegna.
        
        Args:
            session_data (dict): Dati della sessione
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        address = session_data.get("delivery_address", "")
        text = self.translator.get_text("delivery.address_confirm", language).format(address=address)
        buttons = [
            {
                "text": self.translator.get_text("delivery.buttons_confirm.yes", language),
                "callback_data": "yes"
            },
            {
                "text": self.translator.get_text("delivery.buttons_confirm.no", language),
                "callback_data": "no"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["DELIVERY_ADDRESS"]
        }
    
    def _get_payment_method_response(self, language):
        """
        Genera la risposta per la scelta del metodo di pagamento.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("payment.method_question", language)
        buttons = [
            {
                "text": self.translator.get_text("payment.buttons.card", language),
                "callback_data": "card"
            },
            {
                "text": self.translator.get_text("payment.buttons.satispay", language),
                "callback_data": "satispay"
            },
            {
                "text": self.translator.get_text("payment.buttons.cash", language),
                "callback_data": "cash"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["PAYMENT_METHOD"]
        }
    
    def _get_payment_link_response(self, session_data, language):
        """
        Genera la risposta con il link di pagamento.
        
        Args:
            session_data (dict): Dati della sessione
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        # Crea l'ordine se non esiste
        if "order_id" not in session_data:
            order_id = self.order_manager.create_order(
                session_data=session_data,
                user_id=session_data.get("user_id", "unknown")
            )
            session_data["order_id"] = order_id
        
        # Genera il link di pagamento
        payment_method = session_data.get("payment_method", "card")
        payment_link = self.order_manager.generate_payment_link(session_data["order_id"], payment_method)
        
        text = self.translator.get_text("payment.payment_link", language).format(link=payment_link)
        buttons = [
            {
                "text": "✅ Ho completato il pagamento",
                "callback_data": "paid"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["PAYMENT_PROCESSING"]
        }
    
    def _get_cash_payment_response(self, session_data, language):
        """
        Genera la risposta per il pagamento in contanti.
        
        Args:
            session_data (dict): Dati della sessione
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        # Crea l'ordine se non esiste
        if "order_id" not in session_data:
            order_id = self.order_manager.create_order(
                session_data=session_data,
                user_id=session_data.get("user_id", "unknown")
            )
            session_data["order_id"] = order_id
        
        # Ottieni il totale
        total = 0
        if 'cart' in session_data:
            total = session_data['cart']['total']
        
        total_formatted = self.translator.format_currency(total, language)
        text = self.translator.get_text("payment.cash_confirmed", language).format(total=total_formatted)
        
        # Passa direttamente alla conferma dell'ordine
        return self._get_order_confirmation_response(session_data, language)
    
    def _get_order_confirmation_response(self, session_data, language):
        """
        Genera la risposta di conferma dell'ordine.
        
        Args:
            session_data (dict): Dati della sessione
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        order_id = session_data.get("order_id")
        if not order_id:
            # Nessun ordine, torna al carrello
            return self._get_cart_response(session_data, language)
        
        # Ottieni il riepilogo dell'ordine
        order_summary = self.order_manager.get_order_summary(order_id, language)
        
        buttons = [
            {
                "text": self.translator.get_text("confirmation.buttons.track", language),
                "callback_data": "track"
            },
            {
                "text": self.translator.get_text("confirmation.buttons.contact", language),
                "callback_data": "contact"
            },
            {
                "text": self.translator.get_text("confirmation.buttons.home", language),
                "callback_data": "home"
            }
        ]
        
        return {
            "text": order_summary,
            "buttons": buttons,
            "next_state": self.STATES["ORDER_CONFIRMATION"]
        }
    
    def _get_contact_info_response(self, language):
        """
        Genera la risposta con le informazioni di contatto.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        # In un'implementazione reale, qui si fornirebbero i contatti del ristorante
        text = "📞 +39 123 456 7890\n📧 info@pizzeria.com"
        buttons = [
            {
                "text": self.translator.get_text("confirmation.buttons.home", language),
                "callback_data": "home"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["ORDER_CONFIRMATION"]
        }
    
    def _get_faq_response(self, language):
        """
        Genera la risposta con le FAQ.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("faq.intro", language)
        buttons = [
            {
                "text": self.translator.get_text("faq.buttons.hours", language),
                "callback_data": "hours"
            },
            {
                "text": self.translator.get_text("faq.buttons.areas", language),
                "callback_data": "areas"
            },
            {
                "text": self.translator.get_text("faq.buttons.time", language),
                "callback_data": "time"
            },
            {
                "text": self.translator.get_text("faq.buttons.ingredients", language),
                "callback_data": "ingredients"
            },
            {
                "text": self.translator.get_text("faq.buttons.home", language),
                "callback_data": "home"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["FAQ"]
        }
    
    def _get_faq_answer_response(self, topic, language):
        """
        Genera la risposta con la risposta a una FAQ.
        
        Args:
            topic (str): Argomento della FAQ
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text(f"faq.answers.{topic}", language)
        buttons = [
            {
                "text": self.translator.get_text("generic.back", language),
                "callback_data": "back"
            },
            {
                "text": self.translator.get_text("faq.buttons.home", language),
                "callback_data": "home"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["FAQ_ANSWER"]
        }
    
    def _get_language_selection_response(self, language):
        """
        Genera la risposta per la selezione della lingua.
        
        Args:
            language (str): Lingua dell'utente
            
        Returns:
            dict: Risposta
        """
        text = self.translator.get_text("generic.select_language", language)
        buttons = [
            {
                "text": "🇮🇹 Italiano",
                "callback_data": "lang_it"
            },
            {
                "text": "🇷🇺 Русский",
                "callback_data": "lang_ru"
            },
            {
                "text": "🇬🇧 English",
                "callback_data": "lang_en"
            }
        ]
        
        return {
            "text": text,
            "buttons": buttons,
            "next_state": self.STATES["WELCOME"]
        }
