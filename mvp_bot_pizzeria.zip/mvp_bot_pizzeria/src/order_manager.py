"""
Gestione degli ordini per il bot pizzeria
"""

import json
import uuid
from datetime import datetime

class OrderManager:
    """
    Gestisce gli ordini per il bot pizzeria.
    """
    
    def __init__(self, database, translation_manager):
        """
        Inizializza il gestore degli ordini.
        
        Args:
            database: Istanza del database
            translation_manager: Gestore delle traduzioni
        """
        self.db = database
        self.translator = translation_manager
    
    def create_cart(self, session_data):
        """
        Crea un nuovo carrello vuoto nella sessione.
        
        Args:
            session_data (dict): Dati della sessione
            
        Returns:
            dict: Dati della sessione aggiornati
        """
        if 'cart' not in session_data:
            session_data['cart'] = {
                'items': [],
                'total': 0.0
            }
        return session_data
    
    def add_to_cart(self, session_data, item_id, quantity=1):
        """
        Aggiunge un elemento al carrello.
        
        Args:
            session_data (dict): Dati della sessione
            item_id (int): ID dell'elemento da aggiungere
            quantity (int): Quantità da aggiungere
            
        Returns:
            dict: Dati della sessione aggiornati
        """
        # Assicurati che il carrello esista
        session_data = self.create_cart(session_data)
        
        # Ottieni l'elemento dal database
        item = self._get_menu_item(item_id)
        if not item:
            return session_data
        
        # Controlla se l'elemento è già nel carrello
        for cart_item in session_data['cart']['items']:
            if cart_item['item_id'] == item_id:
                # Aggiorna la quantità
                cart_item['quantity'] += quantity
                # Aggiorna il subtotale
                cart_item['subtotal'] = cart_item['price'] * cart_item['quantity']
                break
        else:
            # Aggiungi nuovo elemento al carrello
            session_data['cart']['items'].append({
                'item_id': item_id,
                'name': item['name'],
                'price': item['price'],
                'quantity': quantity,
                'subtotal': item['price'] * quantity
            })
        
        # Aggiorna il totale
        self._update_cart_total(session_data)
        
        return session_data
    
    def remove_from_cart(self, session_data, item_id, quantity=1):
        """
        Rimuove un elemento dal carrello.
        
        Args:
            session_data (dict): Dati della sessione
            item_id (int): ID dell'elemento da rimuovere
            quantity (int): Quantità da rimuovere
            
        Returns:
            dict: Dati della sessione aggiornati
        """
        # Assicurati che il carrello esista
        if 'cart' not in session_data or not session_data['cart']['items']:
            return session_data
        
        # Trova l'elemento nel carrello
        for i, cart_item in enumerate(session_data['cart']['items']):
            if cart_item['item_id'] == item_id:
                # Riduci la quantità
                cart_item['quantity'] -= quantity
                
                # Rimuovi l'elemento se la quantità è 0 o negativa
                if cart_item['quantity'] <= 0:
                    session_data['cart']['items'].pop(i)
                else:
                    # Aggiorna il subtotale
                    cart_item['subtotal'] = cart_item['price'] * cart_item['quantity']
                
                break
        
        # Aggiorna il totale
        self._update_cart_total(session_data)
        
        return session_data
    
    def clear_cart(self, session_data):
        """
        Svuota il carrello.
        
        Args:
            session_data (dict): Dati della sessione
            
        Returns:
            dict: Dati della sessione aggiornati
        """
        session_data['cart'] = {
            'items': [],
            'total': 0.0
        }
        return session_data
    
    def get_cart_summary(self, session_data, language=None):
        """
        Ottiene un riepilogo del carrello formattato.
        
        Args:
            session_data (dict): Dati della sessione
            language (str, optional): Lingua per la formattazione
            
        Returns:
            str: Riepilogo del carrello formattato
        """
        if 'cart' not in session_data or not session_data['cart']['items']:
            return self.translator.get_text("cart.empty", language)
        
        # Intestazione
        summary = self.translator.get_text("cart.intro", language) + "\n\n"
        
        # Elementi
        for i, item in enumerate(session_data['cart']['items'], 1):
            price_formatted = self.translator.format_currency(item['subtotal'], language)
            summary += f"{i}. {item['name']} x{item['quantity']} - {price_formatted}\n"
        
        # Totale
        total_formatted = self.translator.format_currency(session_data['cart']['total'], language)
        summary += "\n" + self.translator.get_text("cart.total", language).format(total=total_formatted)
        
        return summary
    
    def create_order(self, session_data, user_id):
        """
        Crea un nuovo ordine dal carrello.
        
        Args:
            session_data (dict): Dati della sessione
            user_id (str): ID utente
            
        Returns:
            int: ID dell'ordine creato o None se il carrello è vuoto
        """
        if 'cart' not in session_data or not session_data['cart']['items']:
            return None
        
        # Ottieni i dati necessari
        items = session_data['cart']['items']
        total = session_data['cart']['total']
        delivery_method = session_data.get('delivery_method', 'delivery')
        delivery_address = session_data.get('delivery_address', '')
        payment_method = session_data.get('payment_method', 'card')
        
        # Crea l'ordine nel database
        order_id = self.db.create_order(
            user_id=user_id,
            items=items,
            total_amount=total,
            delivery_method=delivery_method,
            delivery_address=delivery_address,
            payment_method=payment_method
        )
        
        # Salva l'ID dell'ordine nella sessione
        session_data['order_id'] = order_id
        
        # Svuota il carrello
        session_data = self.clear_cart(session_data)
        
        return order_id
    
    def get_order_summary(self, order_id, language=None):
        """
        Ottiene un riepilogo dell'ordine formattato.
        
        Args:
            order_id (int): ID dell'ordine
            language (str, optional): Lingua per la formattazione
            
        Returns:
            str: Riepilogo dell'ordine formattato
        """
        order = self.db.get_order(order_id)
        if not order:
            return self.translator.get_text("generic.error", language)
        
        # Intestazione
        summary = self.translator.get_text("confirmation.thank_you", language) + "\n\n"
        summary += self.translator.get_text("confirmation.order_summary", language).format(order_id=order_id) + "\n\n"
        
        # Elementi
        for item in order['items']:
            summary += f"- {item['quantity']}x {item['name']}\n"
        
        # Totale
        total_formatted = self.translator.format_currency(order['total_amount'], language)
        summary += "\n" + self.translator.get_text("cart.total", language).format(total=total_formatted) + "\n\n"
        
        # Messaggio di preparazione
        summary += self.translator.get_text("confirmation.preparation_message", language)
        
        return summary
    
    def generate_payment_link(self, order_id, payment_method="card"):
        """
        Genera un link di pagamento per un ordine.
        
        Args:
            order_id (int): ID dell'ordine
            payment_method (str): Metodo di pagamento
            
        Returns:
            str: Link di pagamento
        """
        order = self.db.get_order(order_id)
        if not order:
            return None
        
        # In un'implementazione reale, qui si integrerebbe con Stripe o Satispay
        # Per l'MVP, generiamo un link fittizio
        
        # Genera un token univoco
        payment_token = str(uuid.uuid4())
        
        # Costruisci il link di pagamento
        if payment_method == "stripe":
            return f"https://pay.example.com/stripe/{payment_token}?amount={order['total_amount']}&order={order_id}"
        elif payment_method == "satispay":
            return f"https://pay.example.com/satispay/{payment_token}?amount={order['total_amount']}&order={order_id}"
        else:
            return f"https://pay.example.com/generic/{payment_token}?amount={order['total_amount']}&order={order_id}"
    
    def update_payment_status(self, order_id, status="completed"):
        """
        Aggiorna lo stato di pagamento di un ordine.
        
        Args:
            order_id (int): ID dell'ordine
            status (str): Nuovo stato di pagamento
            
        Returns:
            bool: True se l'aggiornamento è riuscito
        """
        return self.db.update_payment_status(order_id, status)
    
    def _get_menu_item(self, item_id):
        """
        Ottiene un elemento del menu dal database.
        
        Args:
            item_id (int): ID dell'elemento
            
        Returns:
            dict: Dati dell'elemento o None se non trovato
        """
        # In un'implementazione reale, questa funzione otterrebbe l'elemento dal database
        # Per l'MVP, utilizziamo un menu di esempio
        menu_items = [
            {"item_id": 1, "name": "Margherita", "price": 8.0, "category": "pizzas"},
            {"item_id": 2, "name": "Diavola", "price": 10.0, "category": "pizzas"},
            {"item_id": 3, "name": "Quattro Formaggi", "price": 11.0, "category": "pizzas"},
            {"item_id": 4, "name": "Coca Cola 0.5L", "price": 2.5, "category": "drinks"},
            {"item_id": 5, "name": "Acqua 0.5L", "price": 1.5, "category": "drinks"},
            {"item_id": 6, "name": "Birra 0.33L", "price": 3.5, "category": "drinks"},
            {"item_id": 7, "name": "Menu Coppia", "price": 20.0, "category": "combos"},
            {"item_id": 8, "name": "Menu Famiglia", "price": 30.0, "category": "combos"}
        ]
        
        for item in menu_items:
            if item["item_id"] == item_id:
                return item
        
        return None
    
    def _update_cart_total(self, session_data):
        """
        Aggiorna il totale del carrello.
        
        Args:
            session_data (dict): Dati della sessione
        """
        total = 0.0
        for item in session_data['cart']['items']:
            total += item['subtotal']
        
        session_data['cart']['total'] = total
