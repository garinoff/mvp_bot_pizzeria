import os

BOT_NAME = os.getenv("BOT_NAME", "PizzaBot")
DEFAULT_LANGUAGE = os.getenv("DEFAULT_LANGUAGE", "it")
SUPPORTED_LANGUAGES = os.getenv("SUPPORTED_LANGUAGES", "it,ru,en").split(",")

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
WHATSAPP_API_KEY = os.getenv("WHATSAPP_API_KEY")

DATABASE_PATH = os.getenv("DATABASE_PATH", "data/pizzabot.db")

PAYMENT_PROVIDERS = {
    "stripe": {
        "api_key": os.getenv("STRIPE_API_KEY"),
        "webhook_secret": os.getenv("STRIPE_WEBHOOK_SECRET")
    },
    "satispay": {
        "api_key": os.getenv("SATISPAY_API_KEY"),
        "webhook_secret": os.getenv("SATISPAY_WEBHOOK_SECRET")
    }
}

NOTIFICATION_SETTINGS = {
    "owner_telegram_id": os.getenv("OWNER_TELEGRAM_ID"),
    "owner_email": os.getenv("OWNER_EMAIL")
}

MENU_SOURCE = {
    "type": os.getenv("MENU_SOURCE_TYPE", "google_sheets"),
    "sheet_id": os.getenv("GOOGLE_SHEET_ID"),
    "refresh_interval": int(os.getenv("MENU_REFRESH_INTERVAL", 3600))
}

DELIVERY_TIMES = {
    "preparation": int(os.getenv("DELIVERY_PREPARATION", 20)),
    "delivery": int(os.getenv("DELIVERY_DELIVERY", 20)),
    "total": int(os.getenv("DELIVERY_TOTAL", 40))
}
