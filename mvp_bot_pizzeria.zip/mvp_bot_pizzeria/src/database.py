"""
Gestione del database per il bot pizzeria
"""

import sqlite3
import json
import os
from datetime import datetime
from src.conversation_manager import ConversationManager
from src.translations import TranslationManager

class OrderManager:
    pass  # Если нужен — реализуй отдельно

class Database:
    def __init__(self, db_path):
        """
        Inizializza la connessione al database.
        """
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self._initialize_tables()

    def _initialize_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                chat_id TEXT,
                platform TEXT,
                language TEXT DEFAULT 'it',
                first_name TEXT,
                last_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS orders (
                order_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                status TEXT,
                delivery_method TEXT,
                delivery_address TEXT,
                payment_method TEXT,
                payment_status TEXT,
                total_amount REAL,
                items TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS menu_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT,
                name TEXT,
                description TEXT,
                price REAL,
                image_url TEXT,
                available BOOLEAN DEFAULT 1
            )
        ''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT,
                state TEXT,
                data TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')

        self.conn.commit()

    def get_user(self, user_id, platform):
        self.cursor.execute(
            "SELECT * FROM users WHERE user_id = ? AND platform = ?",
            (user_id, platform)
        )
        user = self.cursor.fetchone()
        return dict(user) if user else None

    def create_or_update_user(self, user_id, platform, chat_id, first_name="", last_name="", language="it"):
        user = self.get_user(user_id, platform)
        if user:
            self.cursor.execute(
                """
                UPDATE users 
                SET chat_id = ?, first_name = ?, last_name = ?, language = ?, last_active = CURRENT_TIMESTAMP
                WHERE user_id = ? AND platform = ?
                """,
                (chat_id, first_name, last_name, language, user_id, platform)
            )
        else:
            self.cursor.execute(
                """
                INSERT INTO users (user_id, platform, chat_id, first_name, last_name, language)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (user_id, platform, chat_id, first_name, last_name, language)
            )
        self.conn.commit()
        return self.get_user(user_id, platform)

    def update_user_language(self, user_id, platform, language):
        self.cursor.execute(
            "UPDATE users SET language = ? WHERE user_id = ? AND platform = ?",
            (language, user_id, platform)
        )
        self.conn.commit()
        return self.cursor.rowcount > 0

    def get_session(self, session_id):
        self.cursor.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,))
        session = self.cursor.fetchone()
        if session:
            session_dict = dict(session)
            if session_dict['data']:
                session_dict['data'] = json.loads(session_dict['data'])
            return session_dict
        return None

    def create_or_update_session(self, session_id, user_id, state, data=None):
        data_json = json.dumps(data or {})
        if self.get_session(session_id):
            self.cursor.execute(
                """
                UPDATE sessions 
                SET state = ?, data = ?, updated_at = CURRENT_TIMESTAMP
                WHERE session_id = ?
                """,
                (state, data_json, session_id)
            )
        else:
            self.cursor.execute(
                """
                INSERT INTO sessions (session_id, user_id, state, data)
                VALUES (?, ?, ?, ?)
                """,
                (session_id, user_id, state, data_json)
            )
        self.conn.commit()
        return self.get_session(session_id)

    def get_menu_items(self, category=None):
        if category:
            self.cursor.execute(
                "SELECT * FROM menu_items WHERE category = ? AND available = 1",
                (category,)
            )
        else:
            self.cursor.execute("SELECT * FROM menu_items WHERE available = 1")
        return [dict(item) for item in self.cursor.fetchall()]

    def get_menu_categories(self):
        self.cursor.execute("SELECT DISTINCT category FROM menu_items WHERE available = 1")
        return [row["category"] for row in self.cursor.fetchall()]

    def create_order(self, user_id, items, total_amount, delivery_method="delivery", delivery_address="", payment_method="card"):
        items_json = json.dumps(items)
        self.cursor.execute(
            """
            INSERT INTO orders 
            (user_id, status, delivery_method, delivery_address, payment_method, payment_status, total_amount, items)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (user_id, "pending", delivery_method, delivery_address, payment_method, "pending", total_amount, items_json)
        )
        self.conn.commit()
        return self.cursor.lastrowid

    def update_order_status(self, order_id, status):
        self.cursor.execute(
            """
            UPDATE orders 
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE order_id = ?
            """,
            (status, order_id)
        )
        self.conn.commit()
        return self.cursor.rowcount > 0

    def update_payment_status(self, order_id, payment_status):
        self.cursor.execute(
            """
            UPDATE orders 
            SET payment_status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE order_id = ?
            """,
            (payment_status, order_id)
        )
        self.conn.commit()
        return self.cursor.rowcount > 0

    def get_order(self, order_id):
        self.cursor.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,))
        order = self.cursor.fetchone()
        if order:
            order_dict = dict(order)
            if order_dict["items"]:
                order_dict["items"] = json.loads(order_dict["items"])
            return order_dict
        return None

    def get_user_orders(self, user_id, limit=5):
        self.cursor.execute(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit)
        )
        result = []
        for order in self.cursor.fetchall():
            order_dict = dict(order)
            if order_dict["items"]:
                order_dict["items"] = json.loads(order_dict["items"])
            result.append(order_dict)
        return result

    def close(self):
        if self.conn:
            self.conn.close()
