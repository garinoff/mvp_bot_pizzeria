from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from src.conversation_manager import ConversationManager
from src.database import Database
from src.translations import TranslationManager
from src.order_manager import OrderManager
import uvicorn
from dotenv import load_dotenv
import os

# Загрузка переменных окружения
load_dotenv()
db_path = os.getenv("DB_PATH", "db.sqlite")
db = Database(db_path=db_path)
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Инициализация зависимостей
translator = TranslationManager()
order_manager = OrderManager(database=db, translation_manager=translator)
conversation = ConversationManager(db, translator, order_manager)

# FastAPI-приложение
app = FastAPI()

# Структура входящего запроса
class IncomingMessage(BaseModel):
    user_id: str
    platform: str  # "telegram" или "whatsapp"
    chat_id: str
    message_text: str
    callback_data: str | None = None

@app.post("/webhook")
async def webhook(msg: IncomingMessage):
    try:
        response = conversation.handle_message(
            user_id=msg.user_id,
            platform=msg.platform,
            chat_id=msg.chat_id,
            message_text=msg.message_text,
            callback_data=msg.callback_data
        )
        return {"status": "ok", "response": response}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/telegram-webhook")
async def telegram_webhook(request: Request):
    data = await request.json()
    response = await conversation.handle_webhook(data)
    return JSONResponse(content=response)

@app.get("/")
async def root():
    return {"message": "PizzaBot is running (FastAPI)"}

if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=5000, reload=True)
