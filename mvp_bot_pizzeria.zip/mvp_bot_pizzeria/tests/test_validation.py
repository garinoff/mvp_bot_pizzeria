"""
Script di validazione per il bot pizzeria
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# Aggiungi la directory src al path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importa i moduli da testare
from src.translations import TranslationManager
from src.database import Database
from src.order_manager import OrderManager
from src.conversation_manager import ConversationManager

class TestTranslationManager(unittest.TestCase):
    """Test per il gestore delle traduzioni"""
    
    def setUp(self):
        self.translator = TranslationManager(default_language="it")
    
    def test_get_text_italian(self):
        """Testa il recupero del testo in italiano"""
        text = self.translator.get_text("welcome.message", "it")
        self.assertIn("Benvenuto", text)
    
    def test_get_text_russian(self):
        """Testa il recupero del testo in russo"""
        text = self.translator.get_text("welcome.message", "ru")
        self.assertIn("Добро пожаловать", text)
    
    def test_get_text_english(self):
        """Testa il recupero del testo in inglese"""
        text = self.translator.get_text("welcome.message", "en")
        self.assertIn("Welcome", text)
    
    def test_fallback_language(self):
        """Testa il fallback alla lingua predefinita"""
        text = self.translator.get_text("welcome.message", "fr")  # Lingua non supportata
        self.assertIn("Benvenuto", text)  # Dovrebbe usare l'italiano
    
    def test_format_currency(self):
        """Testa la formattazione della valuta"""
        # Test euro (italiano)
        euro = self.translator.format_currency(10.5, "it")
        self.assertEqual(euro, "€10.50")
        
        # Test rubli (russo)
        rubles = self.translator.format_currency(10.5, "ru")
        self.assertEqual(rubles, "10.5₽")
        
        # Test euro (inglese)
        euro_en = self.translator.format_currency(10.5, "en")
        self.assertEqual(euro_en, "€10.50")
    
    def test_detect_language(self):
        """Testa il rilevamento della lingua"""
        # Italiano
        lang_it = self.translator.detect_language("Ciao, vorrei ordinare una pizza")
        self.assertEqual(lang_it, "it")
        
        # Russo
        lang_ru = self.translator.detect_language("Привет, я хочу заказать пиццу")
        self.assertEqual(lang_ru, "ru")
        
        # Inglese (fallback)
        lang_en = self.translator.detect_language("Hello, I would like to order a pizza")
        self.assertEqual(lang_en, "en")

class TestOrderManager(unittest.TestCase):
    """Test per il gestore degli ordini"""
    
    def setUp(self):
        # Mock del database
        self.db_mock = MagicMock()
        self.translator = TranslationManager(default_language="it")
        self.order_manager = OrderManager(self.db_mock, self.translator)
    
    def test_create_cart(self):
        """Testa la creazione di un carrello vuoto"""
        session_data = {}
        updated_data = self.order_manager.create_cart(session_data)
        
        self.assertIn('cart', updated_data)
        self.assertEqual(updated_data['cart']['items'], [])
        self.assertEqual(updated_data['cart']['total'], 0.0)
    
    def test_add_to_cart(self):
        """Testa l'aggiunta di un elemento al carrello"""
        session_data = {}
        
        # Mock del metodo _get_menu_item
        self.order_manager._get_menu_item = MagicMock(return_value={
            "item_id": 1,
            "name": "Margherita",
            "price": 8.0
        })
        
        # Aggiungi un elemento
        updated_data = self.order_manager.add_to_cart(session_data, 1)
        
        self.assertEqual(len(updated_data['cart']['items']), 1)
        self.assertEqual(updated_data['cart']['items'][0]['name'], "Margherita")
        self.assertEqual(updated_data['cart']['items'][0]['quantity'], 1)
        self.assertEqual(updated_data['cart']['total'], 8.0)
        
        # Aggiungi lo stesso elemento di nuovo
        updated_data = self.order_manager.add_to_cart(updated_data, 1)
        
        self.assertEqual(len(updated_data['cart']['items']), 1)
        self.assertEqual(updated_data['cart']['items'][0]['quantity'], 2)
        self.assertEqual(updated_data['cart']['total'], 16.0)
    
    def test_remove_from_cart(self):
        """Testa la rimozione di un elemento dal carrello"""
        # Prepara un carrello con un elemento
        session_data = {
            'cart': {
                'items': [
                    {
                        'item_id': 1,
                        'name': "Margherita",
                        'price': 8.0,
                        'quantity': 2,
                        'subtotal': 16.0
                    }
                ],
                'total': 16.0
            }
        }
        
        # Rimuovi un elemento
        updated_data = self.order_manager.remove_from_cart(session_data, 1)
        
        self.assertEqual(len(updated_data['cart']['items']), 1)
        self.assertEqual(updated_data['cart']['items'][0]['quantity'], 1)
        self.assertEqual(updated_data['cart']['total'], 8.0)
        
        # Rimuovi l'ultimo elemento
        updated_data = self.order_manager.remove_from_cart(updated_data, 1)
        
        self.assertEqual(len(updated_data['cart']['items']), 0)
        self.assertEqual(updated_data['cart']['total'], 0.0)
    
    def test_clear_cart(self):
        """Testa lo svuotamento del carrello"""
        # Prepara un carrello con elementi
        session_data = {
            'cart': {
                'items': [
                    {
                        'item_id': 1,
                        'name': "Margherita",
                        'price': 8.0,
                        'quantity': 2,
                        'subtotal': 16.0
                    }
                ],
                'total': 16.0
            }
        }
        
        # Svuota il carrello
        updated_data = self.order_manager.clear_cart(session_data)
        
        self.assertEqual(len(updated_data['cart']['items']), 0)
        self.assertEqual(updated_data['cart']['total'], 0.0)
    
    def test_get_cart_summary(self):
        """Testa il riepilogo del carrello"""
        # Prepara un carrello con elementi
        session_data = {
            'cart': {
                'items': [
                    {
                        'item_id': 1,
                        'name': "Margherita",
                        'price': 8.0,
                        'quantity': 2,
                        'subtotal': 16.0
                    },
                    {
                        'item_id': 4,
                        'name': "Coca Cola 0.5L",
                        'price': 2.5,
                        'quantity': 1,
                        'subtotal': 2.5
                    }
                ],
                'total': 18.5
            }
        }
        
        # Ottieni il riepilogo in italiano
        summary_it = self.order_manager.get_cart_summary(session_data, "it")
        self.assertIn("Margherita", summary_it)
        self.assertIn("Coca Cola", summary_it)
        self.assertIn("€18.50", summary_it)
        
        # Ottieni il riepilogo in russo
        summary_ru = self.order_manager.get_cart_summary(session_data, "ru")
        self.assertIn("Margherita", summary_ru)
        self.assertIn("Coca Cola", summary_ru)
        self.assertIn("18.5₽", summary_ru)
    
    def test_create_order(self):
        """Testa la creazione di un ordine"""
        # Prepara un carrello con elementi
        session_data = {
            'cart': {
                'items': [
                    {
                        'item_id': 1,
                        'name': "Margherita",
                        'price': 8.0,
                        'quantity': 2,
                        'subtotal': 16.0
                    }
                ],
                'total': 16.0
            },
            'delivery_method': 'delivery',
            'delivery_address': 'Via Roma 123',
            'payment_method': 'card'
        }
        
        # Mock del metodo create_order del database
        self.db_mock.create_order.return_value = 12345
        
        # Crea l'ordine
        order_id = self.order_manager.create_order(session_data, "user123")
        
        # Verifica che il database sia stato chiamato correttamente
        self.db_mock.create_order.assert_called_once()
        self.assertEqual(order_id, 12345)
        
        # Verifica che l'ID dell'ordine sia stato salvato nella sessione
        self.assertEqual(session_data['order_id'], 12345)
        
        # Verifica che il carrello sia stato svuotato
        self.assertEqual(len(session_data['cart']['items']), 0)
        self.assertEqual(session_data['cart']['total'], 0.0)

class TestConversationManager(unittest.TestCase):
    """Test per il gestore delle conversazioni"""
    
    def setUp(self):
        # Mock del database e del gestore ordini
        self.db_mock = MagicMock()
        self.translator = TranslationManager(default_language="it")
        self.order_manager_mock = MagicMock()
        
        # Crea il gestore delle conversazioni
        self.conversation_manager = ConversationManager(
            self.db_mock,
            self.translator,
            self.order_manager_mock
        )
    
    def test_get_session(self):
        """Testa il recupero di una sessione"""
        # Mock del metodo get_user del database
        self.db_mock.get_user.return_value = {
            'user_id': 'user123',
            'platform': 'telegram',
            'chat_id': 'chat123',
            'language': 'it'
        }
        
        # Mock del metodo get_session del database
        self.db_mock.get_session.return_value = {
            'session_id': 'telegram_user123',
            'user_id': 'user123',
            'state': 'welcome',
            'data': {}
        }
        
        # Ottieni la sessione
        session_id, session_data, state, language = self.conversation_manager.get_session(
            'user123', 'telegram', 'chat123'
        )
        
        # Verifica i risultati
        self.assertEqual(session_id, 'telegram_user123')
        self.assertEqual(state, 'welcome')
        self.assertEqual(language, 'it')
    
    def test_handle_welcome_state(self):
        """Testa la gestione dello stato di benvenuto"""
        # Test con callback "order"
        response = self.conversation_manager._handle_welcome_state("order", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["MENU_CATEGORIES"])
        
        # Test con callback "menu"
        response = self.conversation_manager._handle_welcome_state("menu", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["MENU_CATEGORIES"])
        
        # Test con callback "faq"
        response = self.conversation_manager._handle_welcome_state("faq", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["FAQ"])
        
        # Test senza callback
        response = self.conversation_manager._handle_welcome_state(None, "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["WELCOME"])
    
    def test_handle_menu_categories_state(self):
        """Testa la gestione dello stato delle categorie del menu"""
        # Test con callback "pizzas"
        response = self.conversation_manager._handle_menu_categories_state("pizzas", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["MENU_ITEMS"])
        
        # Test con callback "cart"
        response = self.conversation_manager._handle_menu_categories_state("cart", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["CART"])
        
        # Test con callback "back"
        response = self.conversation_manager._handle_menu_categories_state("back", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["WELCOME"])
    
    def test_handle_delivery_method_state(self):
        """Testa la gestione dello stato del metodo di consegna"""
        session_data = {}
        
        # Test con callback "delivery"
        response = self.conversation_manager._handle_delivery_method_state(session_data, "delivery", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["DELIVERY_ADDRESS"])
        self.assertEqual(session_data["delivery_method"], "delivery")
        
        # Test con callback "pickup"
        response = self.conversation_manager._handle_delivery_method_state(session_data, "pickup", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["PAYMENT_METHOD"])
        self.assertEqual(session_data["delivery_method"], "pickup")
    
    def test_handle_payment_method_state(self):
        """Testa la gestione dello stato del metodo di pagamento"""
        session_data = {}
        
        # Test con callback "card"
        response = self.conversation_manager._handle_payment_method_state(session_data, "card", "it")
        self.assertEqual(response["next_state"], self.conversation_manager.STATES["PAYMENT_PROCESSING"])
        self.assertEqual(session_data["payment_method"], "card")
        
        # Test con callback "cash"
        response = self.conversation_manager._handle_payment_method_state(session_data, "cash", "it")
        self.assertEqual(session_data["payment_method"], "cash")

if __name__ == '__main__':
    unittest.main()
